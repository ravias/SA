#!/usr/bin/python
from kafka.admin import KafkaAdminClient, NewTopic


admin_client = KafkaAdminClient(
    bootstrap_servers="localhost:9092", 
    client_id='test'
)

topic_list = [NewTopic(name="example-topic", num_partitions=3, replication_factor=1)]
admin_client.create_topics(new_topics=topic_list)

# We can check the topic using Kafka commands to list topics and decribe topics
