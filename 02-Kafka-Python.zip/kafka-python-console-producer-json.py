# Make sure to install kafka-python library using the command: pip install kafka-python

# Make sure to install JSON library using the command: pip install simplejson

from kafka import KafkaProducer
from kafka.errors import KafkaError
import sys
import json

# Create KafkaProducer object
producer = KafkaProducer(bootstrap_servers=['localhost:9092'])

# Publish each line entered on the console (standard input) to the topic
# If the topic specified below is absent, then it will be created.
# If it is present then it will be used for pubishing the data

for line in sys.stdin:
    if len(line)>0:
        mykey, myvalue=line.split(',',1)
        producer.send('json-topic1', key=json.dumps(mykey).encode('utf-8'), value=json.dumps(myvalue).encode('utf-8'))

# To test this we can use console consumer with --property print.key=True parameter as shown below
# bin/kafka-console-consumer.sh --topic json-topic --from-beginning --bootstrap-server localhost:9092 --property print.key=true