# Make sure to install kafka-python library using the command: pip install kafka-python

from kafka import KafkaProducer
from kafka.errors import KafkaError
import sys

# Create KafkaProducer object
producer = KafkaProducer(bootstrap_servers=['localhost:9092'])

# Publish each line entered on the console (standard input) to the topic
# If the topic specified below is absent, then it will be created.
# If it is present then it will be used for pubishing the data

for line in sys.stdin:
    if len(line)>0:
        producer.send('kfpytopic1', line.strip().encode('utf-8'))
        # Alternatively utf-8 encoding can be done as below also
        # producer.send('kfpytopic1', bytes(line.strip(),'utf-8'))
