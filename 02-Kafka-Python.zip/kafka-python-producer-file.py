# Make sure to install kafka-python library using the command: pip install kafka-python

from kafka import KafkaProducer
from kafka.errors import KafkaError
import time

# Create KafkaProducer object
producer = KafkaProducer(bootstrap_servers=['localhost:9092'])

# Publish each line from the given file to the topic
# If the topic specified below is absent, then it will be created.
# If it is present then it will be used for pubishing the data

with open("warandpeace50.txt", "r") as file:
    data = file.readlines()
    for line in data:
        if len(line.strip())>0:
            producer.send('kfpytopic2', line.strip().encode('utf-8'))
            # Alternatively the following syntax can also be used
            # producer.send('kfpytopic2', bytes(line.strip(),'utf-8'))
            time.sleep(2)
