import re
from streamparse.bolt import Bolt

class WeatherBolt(Bolt):
    outputs = ["city","tempC","tempF"]

    def process(self, tup):
        city = tup.values[0]
        tempC = tup.values[1]
        tempF = (int(tempC) * 1.8) + 32
        self.emit([city, tempC, tempF])
        self.log('BOLT city %s: C=%s F=%s' % (city, tempC, tempF))
