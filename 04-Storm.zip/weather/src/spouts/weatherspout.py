import json
from streamparse.spout import Spout
import itertools
from random import randint

class WeatherSpout(Spout):
    outputs = ["city","temp"]

    def initialize(self, stormconf, context):
        self.cities= (
            ["Bangalore", 35],
            ["Chennai", 40],
            ["Hyderabad", 45],
            ["Delhi", 50],
        )

    def next_tuple(self):
        i = randint(0,3)
        citytemp = self.cities[i]
        city = citytemp[0]
        temp = citytemp[1]
        self.emit([city, temp])
        self.log('SPOUT %s: %s' % (city, temp))
