"""
Weather topology
"""

from streamparse import Grouping, Topology

from bolts.weatherbolt import WeatherBolt
from spouts.weatherspout import WeatherSpout


class Weather(Topology):
    weather_spout = WeatherSpout.spec()
    weather_bolt = WeatherBolt.spec(inputs=weather_spout, par=2)
