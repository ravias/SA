"""
Word count2 topology
"""

from streamparse import Grouping, Topology

from spouts.sentences import SentenceSpout
from bolts.sentencesplit import SentenceSplitBolt
from bolts.wordcount import WordCountBolt


class WordCount2(Topology):
    sentence_spout = SentenceSpout.spec()
    split_bolt=SentenceSplitBolt.spec(inputs=sentence_spout)
    count_bolt = WordCountBolt.spec(inputs={split_bolt: Grouping.fields("word")}, par=2)
